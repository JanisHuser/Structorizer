<?php
$structCode = $_GET["structCode"];

/*
$dbUser = "structorizer";
$dbPassword ="oiWf!809";
$dbName = "structorizer";

$conn = new PDO("mysql:host=localhost;dbname=$dbName", $dbUser, $dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->prepare("SELECT * FROM codes WHERE structCode=:structCode");
$stmt1 = $conn->prepare("INSERT INTO codes (structCode, version) VALUES (:structCode, :version)");

$stmt->execute(array('structCode' => $structCode));
$version = 0;
if($stmt->rowCount() > 0 ) {
	$results = $stmt->fetchAll();
	foreach($results as $row) {
		if($row["version"] > $version) {
			$version = $row["version"];
		}
	}
}
*/

if(isset($_GET["v"])) {
		$file = fopen("../sharedStructs/" .$structCode ."/v" .$_GET["v"].".txt", "r");
		$fileContent = fread($file,filesize("../sharedStructs/" .$structCode ."/v" .$_GET["v"].".txt"));
	} else {
		
		$version=0;
		while( file_exists("../sharedStructs/" .$structCode ."/v" .$version.".txt")) {
			
			$version++;
			
		}
	
		$version--;
		$file = fopen("../sharedStructs/" .$structCode ."/v" .$version.".txt", "r");
		$fileContent = fread($file,filesize("../sharedStructs/" .$structCode ."/v" .$version.".txt"));
	}




$fileContent = trim(preg_replace('/\s\s+/', ' ', $fileContent));
fclose($file);

//include "../userControl/main.php";


?>
<!DOCTYPE HTML>
<html>

	<head>
<meta charset="UTF-8">
		<title>Structorizer</title>
		<link rel="icon" href="favicon.png">
		<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<link rel="stylesheet" href="../styles/styleElementsOverView.css"/>
		<script src="../script/convertStructogram.js" type="text/javascript"></script>
		<style>
			@media screen and (max-width: 736px) {
				body {
					font-family: sans-serif;
					margin: 0 auto;
				}
				.header {
					color: white;
					background-color: #3B5998;
					position: relative;
					font-size: 0;
					cursor: pointer;
					
				}
				.header>.title {
					font-size: 20px;
					padding: 0.75em 0.5em;
					width: calc(100% - 1.5em);
					display: inline-block;
					vertical-align: top;
				}
				.header>.title:after {
					display: inline-block;
					float: right;
					margin-right: 0.5em;
					width: 0;
					height: 0;
					border-left: 12px solid transparent;
					border-right: 12px solid transparent;
					border-top: 20px solid #E5E5E5;
					border-bottom: 0px solid #e5e5e5;
					display: inline-block;
					cursor: pointer;
					transition: all .1s ease-in;
					content: ' ';
					margin-top: 2px;
				}
				.header.expanded>.title:after {
					display: inline-block;
					float: right;
					margin-right: 0.5em;
					width: 0;
					height: 0;
					border-left: 12px solid transparent;
					border-right: 12px solid transparent;
					border-bottom: 20px solid #E5E5E5;
					border-top: 0px solid #e5e5e5;
					display: inline-block;
					cursor: pointer;
					transition: all .1s ease-in;
					content: ' ';
				}
				.header>.selectVersion {
					display: none;
				}
				.header>.vote {
					display: none;
				}
				.header>.editStruct {
					display: none;
				}
				
				.header.expanded>.selectVersion {
					display: block;
					background-color: #5170b1;
					padding: 0.5em;
					font-size: 18px;
				}
				.header.expanded>.selectVersion>.smallTitle {
					display: inline-block;
					font-size: 20px;
				}
				.header.expanded>.selectVersion>select {
					display: inline-block;
					font-size: 20px;
					margin-left: 1em;
					background-color: transparent;
					border: none;
					border-bottom: 2px solid white;
					outline: none;
					color: white;
					padding: 0 0.5em;
				}
				.header.expanded>.selectVersion>select>option {
					outline: none;
					color: black;
				}
				
				.tabView {
					overflow: hidden;
					overflow-x: scroll;
					width: 100%;
					height: auto;
					background-color: #e5e5e5;
					white-space: nowrap;
					box-shadow: 0px 2px 2px #b2b2b2;
					font-size: 0;
					padding-bottom: 2px;
				}
				.tabView>.item {
					padding: 0.5em 1em;
					display: inline-block;
					cursor: pointer;
					background-color: #CECECE;
					font-size: 16px;
					box-shadow: 0px 2px #949494;
					margin-right: 3px;
				}
				.tabView>.item>.text {
					text-align: center;
				}
				.tabView>.item:hover,
				.tabView>.item:active {
					background-color: #B9B9B9;
				}
				.tabView>.item.active {
					box-shadow: 0px 2px #3B5998;
				}
			}

			@media screen and (min-width: 737px) {
				body {
					font-family: Verdana;
					margin: 0 auto;
					background-color: #fff;
				}

				.header {
					color: white;
					background-color: #3B5998;
					position: relative;
					font-size: 0;
					box-shadow: 0px 2px 2px #b2b2b2;
					overflow: hidden;
				}
				.header .title {
					font-size: 24px;
					text-align: center;
					padding: 0.75em;
					display: inline-block;
					vertical-align: top;
				}
				.header>.vote {
					display: inline-block;
					float: right;
					font-size: 24px;
					padding: calc(0.75em + 1px);
				}
				.header>.vote>.voteAmount {
					display: inline-block;
				}
				.header>.vote>.voteControl {
					display: inline-block;
				}
				.header>.vote>.voteControl>.voteControlUp {
					width: 0;
					height: 0;
					border-left: 10px solid transparent;
					border-right: 10px solid transparent;
					border-bottom: 20px solid #E5E5E5;
					display: inline-block;
					transition: all .1s ease-in;
					cursor: pointer;
				}
				.header>.vote>.voteControl>.voteControlDown {
					width: 0;
					height: 0;
					border-left: 10px solid transparent;
					border-right: 10px solid transparent;
					border-top: 20px solid #E5E5E5;
					display: inline-block;
					cursor: pointer;
					transition: all .1s ease-in;
				}
				.header>.vote>.voteControl>.voteControlDown:hover {
					border-top: 20px solid #B9B9B9;	
				}
				.header>.vote>.voteControl>.voteControlUp:hover {
					border-bottom: 20px solid #B9B9B9;	
				}
				.header>.selectVersion {
					display: inline-block;
					font-size: 24px;
					padding: 0.75em;
				}
				.header>.selectVersion>.smallTitle {
					display: inline-block;
				}
				.header>.selectVersion>select {
					display: inline-block;
					font-size: 20px;
					padding: 1px;
					outline: none;
					border: none;
					border-bottom: 2px solid white;
					background-color: transparent;
					color: white;
				}
				.header>.selectVersion>select>option {
					color: black;
				}
				.header>.editStruct {
					display: inline-block;
					font-size: 20px;
					float: right;
					padding: 0.75em;
				}
				.header>.editStruct>.singleButton {
					font-size: 18px;
					background-color: #FFA700;
					color: black;
					padding: 0.5em 1em;
					border-radius: 20px;
					cursor: pointer;
					transition: all 0.1s ease-in;
				}
				.header>.editStruct>.singleButton:hover {
					background-color: #E59600;
				}
				.loadingBar {
					top: 0;
					left: 0;
					height: 100%;
					width: 100%;
					z-index: 9999;
					background-color: rgb(49, 51, 123);
					position: fixed;
					display: none;
				}
				.loadingBar>.centerPart {
					margin: 0 auto;
					margin-top: calc(50% - 250px);
					text-align: center;
				}
				.loadingBar>.centerPart>.roundLoadingBar1 {
					margin: 0 auto;
					border: 32px solid #f3f3f3;
					border-top: 32px solid #3498db;
					border-radius: 50%;
					width: 250px;
					height: 250px;
					animation: spin 2s linear infinite;
				}
				@keyframes spin {
					0% { transform: rotate(0deg); }
					100% { transform: rotate(360deg); }
				}
			}
		</style>
		<script>
			$(document).ready(function () {
				$(document).on("click", ".header>.title",function() {
					$(".header").toggleClass("expanded");
				});
				$.ajaxSetup({
					xhr: function(){
						var xhr = new window.XMLHttpRequest();
						//Upload progress
						xhr.upload.addEventListener("progress", function(evt){
							if (evt.lengthComputable) {
								var percentComplete = evt.loaded / evt.total;
								$(".loadingBar").show();
								$(".loadingBar .loadedPart").css("width", (percentComplete*100) + '%');
							}
						}, false);
						//Download progress
						xhr.addEventListener("progress", function(evt){
							if (evt.lengthComputable) {
								var percentComplete = evt.loaded / evt.total;
								$(".loadingBar").show();
								$(".loadingBar .loadedPart").css("width", (percentComplete*100) + '%');
							}
						}, false);
						//Loaded complete
						xhr.addEventListener("load", function(evt) {
							$(".loadingBar").hide();
						}, false);
						return xhr;
					},
					type: 'POST',
					url: "/",
					data: {},
					async: 'true',
					success: function(data){
						$(".loadingBar .loadedPart").hide();
					}
				});
				
				$(document).on("click", ".structTabs>.tabItem", function() {
					$(".structTabs .tabItem").removeClass("active");
					$(this).addClass("active");
					$(".mainStruct").hide();
					$(".mainStruct#mainStruct" + $(this).attr("id")).show();
				});
				loadContent();
				
				
				
				$(document).on("change", ".selectVersion>select", function() {
					var href = window.location.href.split("?structCode=");
					var structCode;
					if(href.length > 1 && href[1].indexOf("&v") != -1) {
						structCode = href[1].split("&v")[0];
					} else {
						structCode = href[1];
					}
					var stateObj = { foo: "bar" };
					history.pushState(stateObj, structCode + "v:" + $(this).val(), window.location.origin + "/loadStruct/?structCode=" + structCode + "&v=" + $(this).val());
					window.location.replace(window.location.origin + "/loadStruct/?structCode=" + structCode + "&v=" + $(this).val());
				});
				
				$(".elemStruct").removeClass("draggable").attr("draggable", "false");
				
				$(document).on("click", ".header>.editStruct", function() {
					var href = window.location.href.split("?structCode=");
					var structCode;
					if(href.length > 1 && href[1].indexOf("&v") != -1) {
						structCode = href[1].split("&v")[0];
					} else {
						structCode = href[1];
					}
					var stateObj = { foo: "bar" };
					history.pushState(stateObj, "structorizer", "https://www.structorizer.com/struct.php?structCode=" + structCode + "&v=" + $(".selectVersion>select").val());
					window.location.replace("https://www.structorizer.com/struct.php?structCode=" + structCode + "&v=" + $(".selectVersion>select").val());
					
				});
				
				$(document).on("click", ".header>.vote>.voteControl>.voteControlDown", function() {
					
				});
				
				$(document).on("click", ".header>.vote>.voteControl>.voteControlUp", function() {
					var formData = new FormData();
					formData.append("structCode", "<?php echo $_GET["structCode"]; ?>");
					formData.append("version", "<?php echo $_GET["v"]; ?>");
					formData.append("type", "1");
					$.ajax({
					url: "../userControl/vote.php",
					type: 'post',
					data: formData,
					dataType: 'html',
					async: true,
					processData: false,
					contentType: false,
					success: function(data) {
					}
				});
				});
			});
			
			String.prototype.replaceAll = function(search, replacement) {
				var target = this;
				return target.replace(new RegExp(search, 'g'), replacement);
			};
			
			function loadContent() {
				$(".loadingBar").show();
				$(".mainContent").html(openStructogramm('<?php echo $fileContent; ?>' , "structio"));
				$(".loadingBar").hide();
				
			}
		</script>
	</head>

	<body>
		<div class="header">
			<div class="title">Aktuelles Projekt: <div style="display: inline-block; font-style: oblique; font-size: 18px;"><?php echo explode("v_",$_GET["structCode"])[0]; ?></div></div>
			
			<div class="selectVersion">
				<div class="smallTitle">Version:</div>
				<select>
					<?php
						$i=0;

						if($stmt->rowCount() > 0 ) {
							foreach($results as $row) {
								$i++;
								if( !isset($_GET["v"])) {
									if($i >= count($results)) {
										echo "<option selected value='". $row["version"]."'>" .$row["version"] ."</option>";
									} else {
										echo "<option value='". $row["version"]."'>" .$row["version"] ."</option>";
									}
								} else {
									if(($i-1) == $_GET["v"]) {
										echo "<option selected value='". $row["version"]."'>" .$row["version"] ."</option>";
									} else {
										echo "<option value='". $row["version"]."'>" .$row["version"] ."</option>";
									}
								}
								
							}
						}

					?>
				</select>
			</div>
			<div class="vote">
				<div class="voteAmount">0</div>
				<div class="voteControl">
					<div class="voteControlUp"></div>
					<div class="voteControlDown"></div>
				</div>
			</div>
			<div class="editStruct">
				<div class="singleButton">Struktogramm bearbeiten</div>
			</div>
			
			
			
		</div>
		<div class="structTabs">
			<div class="openNewTab"></div>
		</div>
		<div class="structContent">
		</div>
		
		<div class="loadingBar">
			<div class="centerPart">
				<div class="roundLoadingBar1"></div>
			</div>
		</div>
	</body>

</html>